package games.example.P4ndagames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P4ndagamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
