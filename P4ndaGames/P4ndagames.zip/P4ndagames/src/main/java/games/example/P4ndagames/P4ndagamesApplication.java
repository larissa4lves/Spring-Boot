package games.example.P4ndagames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P4ndagamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(P4ndagamesApplication.class, args);
	}

}
